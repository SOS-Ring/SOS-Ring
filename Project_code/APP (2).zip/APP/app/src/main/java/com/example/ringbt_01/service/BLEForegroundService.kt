package com.example.ringbt_01.service

import android.annotation.SuppressLint
import android.app.*
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.os.Build
import android.os.IBinder
import android.telephony.SmsManager
import android.util.Log
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.example.ringbt_01.MainActivity
import com.example.ringbt_01.ble.BleManager
import com.example.ringbt_01.data.AppSettings
import com.example.ringbt_01.data.SettingsRepository
import com.example.ringbt_01.debug.DebugLogger
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class BLEForegroundService : LifecycleService() {

    private lateinit var bleManager: BleManager
    private lateinit var settingsRepository: SettingsRepository
    private var currentSettings: AppSettings = AppSettings()
    
    private var isTriggering = false

    companion object {
        private const val CHANNEL_ID = "BLE_SERVICE_CHANNEL"
        private const val NOTIFICATION_ID = 1
        const val TRIGGER_STRING = "ale23"
    }

    override fun onCreate() {
        super.onCreate()
        bleManager = com.example.ringbt_01.ble.BleProvider.getBleManager(this)
        settingsRepository = SettingsRepository(this)
        createNotificationChannel()
        startForegroundSafely("In attesa di connessione...")

        lifecycleScope.launch {
            settingsRepository.settingsFlow.collectLatest { settings ->
                val oldAddress = currentSettings.sosRingAddress
                currentSettings = settings
                
                if (settings.sosRingAddress.isNotEmpty()) {
                    if (settings.sosRingAddress != oldAddress || bleManager.connectionState.value == BluetoothProfile.STATE_DISCONNECTED) {
                        Log.d("BLEService", "Tentativo di connessione a ${settings.sosRingAddress}")
                        bleManager.connect(settings.sosRingAddress)
                    }
                } else {
                    Log.d("BLEService", "Indirizzo rimosso, disconnessione...")
                    bleManager.disconnect()
                }
            }
        }

        lifecycleScope.launch {
            bleManager.receivedData.collect { data ->
                if (data.isNotEmpty()) {
                    val normalizedData = data.lowercase().trim()
                    Log.d("BLEService", "Analisi buffer: '$normalizedData'")
                    DebugLogger.log("BLE", "Buffer: '$normalizedData'")
                    
                    // Toast di debug per qualsiasi dato ricevuto via BLE (se abilitato da Lab)
                    if (com.example.ringbt_01.debug.DebugConfig.showDebugToasts) {
                        withContext(Dispatchers.Main) {
                            Toast.makeText(
                                applicationContext,
                                "DEBUG BLE: '$data'",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                    
                    if (normalizedData.contains(TRIGGER_STRING.lowercase()) && !isTriggering) {
                        Log.d("BLEService", "!!! MATCH TRIGGER TROVATO !!!")
                        DebugLogger.log("SOS", "🚨 TRIGGER '$TRIGGER_STRING' TROVATO! Avvio sequenza...")
                        isTriggering = true
                        
                        // Toast di debug quando la stringa trigger viene riconosciuta (se abilitato da Lab)
                        if (com.example.ringbt_01.debug.DebugConfig.showDebugToasts) {
                            withContext(Dispatchers.Main) {
                                Toast.makeText(
                                    applicationContext,
                                    "🚨 TRIGGER '$TRIGGER_STRING' RICEVUTO! Avvio SOS...",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        }
                        
                        bleManager.clearData()
                        handleTrigger()
                        
                        // Debounce breve (5 secondi) per evitare invii doppi accidentali
                        lifecycleScope.launch {
                            delay(5000)
                            isTriggering = false
                        }
                    }
                }
            }
        }

        lifecycleScope.launch {
            bleManager.connectionState.collect { state ->
                Log.d("BLEService", "Nuovo stato connessione: $state")
                val statusText = when (state) {
                    BluetoothProfile.STATE_CONNECTED -> "Connesso a SOS RING"
                    BluetoothProfile.STATE_DISCONNECTED -> "Disconnesso"
                    BluetoothProfile.STATE_CONNECTING -> "Connessione in corso..."
                    else -> "Stato: $state"
                }
                updateNotification(statusText)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        return START_STICKY
    }

    @SuppressLint("MissingPermission")
    private fun handleTrigger() {
        Log.d("BLEService", "handleTrigger avviato: priorità alla chiamata SOS")

        // 1. AVVIA SUBITO IL SERVIZIO CHIAMATE (priorità massima per la chiamata vocale)
        startEmergencyCallService()

        // 2. INVIA 1 SINGOLO SMS (testo + posizione uniti) SOLAMENTE AL PRIMO CONTATTO
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val fusedLocationClient = LocationServices.getFusedLocationProviderClient(this@BLEForegroundService)
                val smsSent = java.util.concurrent.atomic.AtomicBoolean(false)

                fun doSend(loc: Location?) {
                    if (smsSent.compareAndSet(false, true)) {
                        sendSingleSmsToFirstContact(loc)
                    }
                }

                // Tenta di recuperare la posizione GPS attuale
                fusedLocationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
                    .addOnSuccessListener { location: Location? ->
                        if (location != null) {
                            doSend(location)
                        } else {
                            fusedLocationClient.lastLocation.addOnSuccessListener { lastLoc ->
                                doSend(lastLoc)
                            }.addOnFailureListener {
                                doSend(null)
                            }
                        }
                    }
                    .addOnFailureListener {
                        fusedLocationClient.lastLocation.addOnSuccessListener { lastLoc ->
                            doSend(lastLoc)
                        }.addOnFailureListener {
                            doSend(null)
                        }
                    }

                // Timeout di sicurezza di 4 secondi per non bloccare l'invio se il GPS ritarda
                delay(4000)
                if (!smsSent.get()) {
                    fusedLocationClient.lastLocation.addOnSuccessListener { lastLoc ->
                        doSend(lastLoc)
                    }.addOnFailureListener {
                        doSend(null)
                    }
                }
            } catch (e: Exception) {
                Log.e("BLEService", "Errore procedura SMS/GPS nel trigger", e)
                DebugLogger.log("SOS", "❌ Errore procedura SMS/GPS: ${e.message}")
            }
        }
    }

    private fun startEmergencyCallService() {
        val contacts = listOf(currentSettings.contact1, currentSettings.contact2, currentSettings.contact3)
            .filter { it.isNotEmpty() }

        if (contacts.isEmpty()) {
            Log.w("BLEService", "Nessun contatto configurato per le chiamate")
            return
        }

        Log.d("BLEService", "Avvio EmergencyCallService con contatti: $contacts")
        
        try {
            val serviceIntent = EmergencyCallService.createIntent(this, contacts)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
        } catch (e: Exception) {
            Log.e("BLEService", "Errore avvio EmergencyCallService", e)
        }
    }

    private fun sendSingleSmsToFirstContact(location: Location?) {
        val contact = currentSettings.contact1.trim()
        if (contact.isEmpty()) {
            Log.w("BLEService", "Nessun primo contatto configurato per l'invio SMS")
            return
        }

        val fullMessage = if (location != null) {
            val locationUrl = "https://www.google.com/maps/search/?api=1&query=${location.latitude},${location.longitude}"
            "${currentSettings.smsMessage}\nPosizione:\n$locationUrl"
        } else {
            currentSettings.smsMessage
        }

        val smsManager: SmsManager? = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                this.getSystemService(SmsManager::class.java) ?: @Suppress("DEPRECATION") SmsManager.getDefault()
            } else {
                @Suppress("DEPRECATION")
                SmsManager.getDefault()
            }
        } catch (e: Exception) {
            Log.e("BLEService", "Impossibile ottenere SmsManager", e)
            null
        }

        if (smsManager == null) {
            Log.w("BLEService", "SmsManager non disponibile su questo dispositivo (es. tablet Wi-Fi o senza SIM)")
            DebugLogger.log("SMS", "⚠️ SMS non inviabili: modulo telefonico/SMS assente sul dispositivo")
            return
        }

        try {
            val parts = smsManager.divideMessage(fullMessage)
            if (parts != null && parts.size > 1) {
                smsManager.sendMultipartTextMessage(contact, null, parts, null, null)
                Log.d("BLEService", "1 SMS multipart inviato al 1° contatto ($contact): $fullMessage")
                DebugLogger.log("SMS", "1 SMS multipart inviato al 1° contatto ($contact)")
            } else {
                smsManager.sendTextMessage(contact, null, fullMessage, null, null)
                Log.d("BLEService", "1 SMS singolo inviato al 1° contatto ($contact): $fullMessage")
                DebugLogger.log("SMS", "1 SMS singolo inviato al 1° contatto ($contact)")
            }
        } catch (e: Exception) {
            Log.e("BLEService", "Errore invio SMS a $contact", e)
            DebugLogger.log("SMS", "❌ Errore SMS a $contact: ${e.message}")
        }
    }

    private fun startForegroundSafely(statusText: String) {
        val notification = createNotification(statusText)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                var serviceType = 0
                val hasBt = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    ContextCompat.checkSelfPermission(
                        this, android.Manifest.permission.BLUETOOTH_CONNECT
                    ) == PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(
                        this, android.Manifest.permission.BLUETOOTH_SCAN
                    ) == PackageManager.PERMISSION_GRANTED
                } else true

                val hasLocation = ContextCompat.checkSelfPermission(
                    this, android.Manifest.permission.ACCESS_FINE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(
                    this, android.Manifest.permission.ACCESS_COARSE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED

                if (hasBt) {
                    serviceType = serviceType or ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
                }
                if (hasLocation) {
                    serviceType = serviceType or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
                }

                if (serviceType != 0) {
                    startForeground(
                        NOTIFICATION_ID,
                        notification,
                        serviceType
                    )
                } else {
                    Log.w("BLEService", "Permessi BLE/Location non ancora concessi. Avvio FGS in modalità fallback.")
                    startForeground(
                        NOTIFICATION_ID,
                        notification
                    )
                }
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Exception) {
            Log.e("BLEService", "Impossibile avviare il servizio in foreground (permessi non pronti)", e)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val serviceChannel = NotificationChannel(
                CHANNEL_ID,
                "Canale Servizio BLE",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(serviceChannel)
        }
    }

    private fun createNotification(content: String): Notification {
        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, notificationIntent,
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Monitoraggio SOS RING Attivo")
            .setContentText(content)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentIntent(pendingIntent)
            .build()
    }

    private fun updateNotification(content: String) {
        try {
            val notification = createNotification(content)
            val manager = getSystemService(NotificationManager::class.java)
            manager.notify(NOTIFICATION_ID, notification)
        } catch (e: Exception) {
            Log.e("BLEService", "Errore aggiornamento notifica", e)
        }
    }

    override fun onBind(intent: Intent): IBinder? {
        super.onBind(intent)
        return null
    }
}
