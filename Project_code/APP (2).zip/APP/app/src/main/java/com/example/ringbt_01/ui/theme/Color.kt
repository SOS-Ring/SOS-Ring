package com.example.ringbt_01.ui.theme

import androidx.compose.ui.graphics.Color

// Default Theme Colors
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Custom Themes Colors
// Dark Red
val DarkRedPrimary = Color(0xFFFF3B30)
val DarkRedOnPrimary = Color(0xFFFFFFFF)
val DarkRedPrimaryContainer = Color(0xFF4A0000)
val DarkRedOnPrimaryContainer = Color(0xFFFFB4AB)
val DarkRedBackground = Color(0xFF000000)
val DarkRedSurface = Color(0xFF141414)
val DarkRedSurfaceVariant = Color(0xFF241A1A)

// Dark Yellow
val DarkYellowPrimary = Color(0xFFFFD600)
val DarkYellowOnPrimary = Color(0xFF000000)
val DarkYellowPrimaryContainer = Color(0xFF403600)
val DarkYellowOnPrimaryContainer = Color(0xFFFFE082)
val DarkYellowBackground = Color(0xFF000000)
val DarkYellowSurface = Color(0xFF141414)
val DarkYellowSurfaceVariant = Color(0xFF252216)

// Dark Green
val DarkGreenPrimary = Color(0xFF00E676)
val DarkGreenOnPrimary = Color(0xFF003915)
val DarkGreenPrimaryContainer = Color(0xFF005322)
val DarkGreenOnPrimaryContainer = Color(0xFF69FF9E)
val DarkGreenBackground = Color(0xFF000000)
val DarkGreenSurface = Color(0xFF141414)
val DarkGreenSurfaceVariant = Color(0xFF16241B)

// Dark Blue
val DarkBluePrimary = Color(0xFF00B0FF)
val DarkBlueOnPrimary = Color(0xFF00344F)
val DarkBluePrimaryContainer = Color(0xFF004C70)
val DarkBlueOnPrimaryContainer = Color(0xFFBCE9FF)
val DarkBlueBackground = Color(0xFF000000)
val DarkBlueSurface = Color(0xFF141414)
val DarkBlueSurfaceVariant = Color(0xFF161F26)

// Light White
val LightWhitePrimary = Color(0xFF1976D2)
val LightWhiteOnPrimary = Color(0xFFFFFFFF)
val LightWhitePrimaryContainer = Color(0xFFE3F2FD)
val LightWhiteOnPrimaryContainer = Color(0xFF0D47A1)
val LightWhiteBackground = Color(0xFFFAFAFA)
val LightWhiteSurface = Color(0xFFFFFFFF)
val LightWhiteSurfaceVariant = Color(0xFFECEFF1)
val LightWhiteOnSurface = Color(0xFF212121)
val LightWhiteOnSurfaceVariant = Color(0xFF424242)