package com.example.ringbt_01.ui.screens

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.ContactsContract
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ringbt_01.MainViewModel

@Composable
fun HomeScreen(viewModel: MainViewModel) {
    val settings by viewModel.settings.collectAsState()
    val connectionState by viewModel.connectionState.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f),
                        MaterialTheme.colorScheme.surface
                    )
                )
            )
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(40.dp))
        
        // Bluetooth Status Circle
        Box(
            modifier = Modifier
                .size(200.dp)
                .clip(CircleShape)
                .background(
                    when (connectionState) {
                        2 -> Color(0xFFE8F5E9) // Green light
                        1 -> Color(0xFFFFF8E1) // Yellow light
                        else -> Color(0xFFF5F5F5) // Gray light
                    }
                ),
            contentAlignment = Alignment.Center
        ) {
            val iconColor = when (connectionState) {
                2 -> Color(0xFF4CAF50)
                1 -> Color(0xFFFFC107)
                else -> Color.Gray
            }
            Icon(
                imageVector = if (connectionState == 2) Icons.Default.BluetoothConnected else Icons.Default.Bluetooth,
                contentDescription = null,
                modifier = Modifier.size(80.dp),
                tint = iconColor
            )
        }
        
        Spacer(modifier = Modifier.height(32.dp))
        
        Text(
            text = when (connectionState) {
                2 -> "Dispositivo Connesso"
                1 -> "Connessione in corso..."
                else -> "Dispositivo Scollegato"
            },
            fontSize = 24.sp,
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.onSurface
        )
        
        Text(
            text = if (settings.sosRingAddress.isEmpty()) "Configura l'indirizzo nelle impostazioni" else "SOS RING: ${settings.sosRingAddress}",
            fontSize = 14.sp,
            color = Color.Gray
        )
        
        Spacer(modifier = Modifier.weight(1f))
        
        // Alert Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.9f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Security, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text("Protezione Attiva", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                    Text(
                        "L'app monitora SOS RING per la tua sicurezza. Non chiudere l'app.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                }
            }
        }
    }
}

@Composable
fun ContactsScreen(viewModel: MainViewModel) {
    val settings by viewModel.settings.collectAsState()
    val context = LocalContext.current
    
    var c1 by remember(settings.contact1) { mutableStateOf(settings.contact1) }
    var c2 by remember(settings.contact2) { mutableStateOf(settings.contact2) }
    var c3 by remember(settings.contact3) { mutableStateOf(settings.contact3) }

    var pickingFor by remember { mutableStateOf(0) }

    val contactPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickContact()) { uri ->
        uri?.let {
            val number = getPhoneNumber(context, it)
            when (pickingFor) {
                1 -> c1 = number
                2 -> c2 = number
                3 -> c3 = number
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("I tuoi contatti di emergenza", style = MaterialTheme.typography.headlineSmall)
        Text("Saranno chiamati in ordine se non rispondono.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        Spacer(modifier = Modifier.height(24.dp))
        
        ContactPickerField(label = "Contatto 1", value = c1, onPick = { pickingFor = 1; contactPicker.launch(null) })
        Spacer(modifier = Modifier.height(16.dp))
        ContactPickerField(label = "Contatto 2", value = c2, onPick = { pickingFor = 2; contactPicker.launch(null) })
        Spacer(modifier = Modifier.height(16.dp))
        ContactPickerField(label = "Contatto 3", value = c3, onPick = { pickingFor = 3; contactPicker.launch(null) })
        
        Spacer(modifier = Modifier.height(32.dp))
        Button(
            onClick = { 
                viewModel.updateContacts(c1, c2, c3)
                Toast.makeText(context, "Contatti salvati con successo", Toast.LENGTH_SHORT).show()
            },
            modifier = Modifier.fillMaxWidth(),
            shape = MaterialTheme.shapes.medium
        ) {
            Text("Salva Lista Emergenza")
        }
    }
}

@Composable
fun ContactPickerField(label: String, value: String, onPick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(label, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                Text(
                    text = if (value.isEmpty()) "Nessun contatto selezionato" else value,
                    style = MaterialTheme.typography.bodyLarge
                )
            }
            IconButton(onClick = onPick) {
                Icon(Icons.Default.Person, contentDescription = "Seleziona", tint = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
fun GuideScreen(onSecretTrigger: (() -> Unit)? = null) {
    val context = LocalContext.current
    var titleTapCount by remember { mutableStateOf(0) }
    var lastTitleTapTime by remember { mutableStateOf(0L) }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = "Guida ai Permessi",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.clickable {
                val now = System.currentTimeMillis()
                if (now - lastTitleTapTime < 1500L) {
                    titleTapCount++
                } else {
                    titleTapCount = 1
                }
                lastTitleTapTime = now
                if (titleTapCount >= 4) {
                    titleTapCount = 0
                    onSecretTrigger?.invoke()
                }
            }
        )
        Text(
            "Per funzionare correttamente in background, l'app richiede alcuni permessi speciali.",
            style = MaterialTheme.typography.bodyMedium,
            color = Color.Gray
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        PermissionGuideItem(
            title = "Posizione (Sempre)",
            description = "Consente di trovare il tuo SOS RING e inviare le coordinate GPS anche se lo schermo è spento.",
            icon = Icons.Default.LocationOn,
            actionLabel = "Vai a Impostazioni",
            onClick = {
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.fromParts("package", context.packageName, null)
                }
                context.startActivity(intent)
            }
        )
        
        PermissionGuideItem(
            title = "Visualizzazione Sopra Altre App",
            description = "Necessario per avviare la chiamata di emergenza automaticamente quando scatta l'allarme.",
            icon = Icons.Default.Layers,
            actionLabel = "Attiva Overlay",
            onClick = {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
                        data = Uri.parse("package:${context.packageName}")
                    }
                    context.startActivity(intent)
                }
            }
        )
        
        PermissionGuideItem(
            title = "Ottimizzazione Batteria",
            description = "Disattiva il risparmio energetico per RingBT così il Bluetooth non verrà mai interrotto.",
            icon = Icons.Default.BatteryChargingFull,
            actionLabel = "Disattiva Risparmio",
            onClick = {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                    context.startActivity(intent)
                }
            }
        )

        Spacer(modifier = Modifier.height(24.dp))
        Text(
            "Nota: Se l'app non effettua chiamate in background, controlla che 'Visualizza sopra altre app' sia ATTIVO.",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.primary,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun PermissionGuideItem(title: String, description: String, icon: androidx.compose.ui.graphics.vector.ImageVector, actionLabel: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(12.dp))
                Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(description, style = MaterialTheme.typography.bodySmall)
            Spacer(modifier = Modifier.height(12.dp))
            TextButton(
                onClick = onClick,
                modifier = Modifier.align(Alignment.End)
            ) {
                Text(actionLabel)
            }
        }
    }
}

@Composable
fun SettingsScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val settings by viewModel.settings.collectAsState()
    val discoveredDevices by viewModel.discoveredDevices.collectAsState()
    val isBtEnabled by viewModel.isBluetoothEnabled.collectAsState()
    
    var message by remember(settings.smsMessage) { mutableStateOf(settings.smsMessage) }
    var showDeviceDialog by remember { mutableStateOf(false) }
    var showAlert by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("Impostazioni Generali", style = MaterialTheme.typography.headlineSmall)
        Spacer(modifier = Modifier.height(16.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Dispositivo Associato", fontWeight = FontWeight.Bold)
                Text(
                    text = if (settings.sosRingAddress.isEmpty()) "Nessun dispositivo selezionato" else "Indirizzo: ${settings.sosRingAddress}",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = {
                        if (viewModel.isBtOn()) {
                            viewModel.startScanning()
                            showDeviceDialog = true
                        } else {
                            showAlert = true
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.BluetoothSearching, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Cerca SOS RING")
                }

                if (settings.sosRingAddress.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = { viewModel.disconnect() },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                    ) {
                        Icon(Icons.Default.BluetoothDisabled, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Disconnetti")
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        OutlinedTextField(
            value = message,
            onValueChange = { message = it },
            label = { Text("Messaggio SMS") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 3
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        Button(
            onClick = {
                viewModel.updateSmsMessage(message)
                Toast.makeText(context, "Messaggio salvato!", Toast.LENGTH_SHORT).show()
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Salva Messaggio")
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Sezione Tema dell'Applicazione
        Text("Tema dell'Applicazione", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("Scegli la combinazione di colori che preferisci", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        Spacer(modifier = Modifier.height(12.dp))

        ThemeSelectionCard(
            currentTheme = settings.appTheme,
            onThemeSelected = { newTheme ->
                viewModel.updateAppTheme(newTheme)
                Toast.makeText(context, "Tema aggiornato!", Toast.LENGTH_SHORT).show()
            }
        )

        Spacer(modifier = Modifier.height(24.dp))
    }

    if (showDeviceDialog) {
        DeviceSelectionDialog(
            devices = discoveredDevices,
            onDeviceSelected = { device ->
                viewModel.updateSosRingAddress(device.address)
                viewModel.stopScanning()
                showDeviceDialog = false
            },
            onDismiss = {
                viewModel.stopScanning()
                showDeviceDialog = false
            }
        )
    }

    if (showAlert) {
        AlertDialog(
            onDismissRequest = { showAlert = false },
            title = { Text("Bluetooth Disattivato") },
            text = { Text("Attiva il Bluetooth per poterti collegare a SOS RING e riprova.") },
            confirmButton = {
                Button(onClick = { showAlert = false }) {
                    Text("OK")
                }
            }
        )
    }
}

@SuppressLint("MissingPermission")
@Composable
fun DeviceSelectionDialog(
    devices: List<BluetoothDevice>,
    onDeviceSelected: (BluetoothDevice) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Seleziona SOS RING") },
        text = {
            if (devices.isEmpty()) {
                Box(modifier = Modifier.fillMaxWidth().height(100.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else {
                LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 300.dp)) {
                    items(devices) { device ->
                        ListItem(
                            headlineContent = { Text(device.name ?: "Unknown Device") },
                            supportingContent = { Text(device.address) },
                            modifier = Modifier.clickable { onDeviceSelected(device) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Annulla") }
        }
    )
}

@SuppressLint("Range")
private fun getPhoneNumber(context: android.content.Context, contactUri: Uri): String {
    var phoneNumber = ""
    val cursor = context.contentResolver.query(contactUri, null, null, null, null)
    if (cursor != null && cursor.moveToFirst()) {
        val id = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID))
        val hasPhoneNumber = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER))
        if (hasPhoneNumber == "1") {
            val phoneCursor = context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                null,
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                arrayOf(id),
                null
            )
            if (phoneCursor != null && phoneCursor.moveToFirst()) {
                phoneNumber = phoneCursor.getString(phoneCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER))
                phoneCursor.close()
            }
        }
        cursor.close()
    }
    return phoneNumber.replace(" ", "").replace("-", "")
}

data class ThemeOption(
    val id: String,
    val title: String,
    val subtitle: String,
    val previewColor: Color,
    val previewBg: Color
)

@Composable
fun ThemeSelectionCard(
    currentTheme: String,
    onThemeSelected: (String) -> Unit
) {
    val themeOptions = listOf(
        ThemeOption("SYSTEM", "Predefinito di Sistema", "Segue il tema automatico del dispositivo", Color(0xFF6750A4), Color(0xFF1C1B1F)),
        ThemeOption("DARK_RED", "Nero e Rosso", "Sfondo nero puro con accenti rossi SOS", Color(0xFFFF3B30), Color(0xFF000000)),
        ThemeOption("DARK_YELLOW", "Nero e Giallo", "Sfondo nero puro con accenti giallo brillante", Color(0xFFFFD600), Color(0xFF000000)),
        ThemeOption("DARK_GREEN", "Nero e Verde", "Sfondo nero puro con accenti verde smeraldo", Color(0xFF00E676), Color(0xFF000000)),
        ThemeOption("DARK_BLUE", "Nero e Blu", "Sfondo nero puro con accenti blu elettrico", Color(0xFF00B0FF), Color(0xFF000000)),
        ThemeOption("LIGHT_WHITE", "Bianco / Chiaro", "Tema luminoso ad alto contrasto", Color(0xFF1976D2), Color(0xFFFFFFFF))
    )

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            themeOptions.forEachIndexed { index, option ->
                val isSelected = currentTheme == option.id || (currentTheme.isEmpty() && option.id == "SYSTEM")

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(MaterialTheme.shapes.small)
                        .clickable { onThemeSelected(option.id) }
                        .padding(horizontal = 8.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = isSelected,
                        onClick = { onThemeSelected(option.id) }
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    // Color Preview Badge
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(option.previewBg)
                            .padding(4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(18.dp)
                                .clip(CircleShape)
                                .background(option.previewColor)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = option.title,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            style = MaterialTheme.typography.bodyLarge
                        )
                        Text(
                            text = option.subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )
                    }
                }

                if (index < themeOptions.size - 1) {
                    HorizontalDivider(
                        modifier = Modifier.padding(horizontal = 16.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.1f)
                    )
                }
            }
        }
    }
}
