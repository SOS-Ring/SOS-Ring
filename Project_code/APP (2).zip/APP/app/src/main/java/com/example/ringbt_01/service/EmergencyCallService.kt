package com.example.ringbt_01.service

import android.annotation.SuppressLint
import android.app.*
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.telecom.TelecomManager
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import android.util.Log
import android.view.KeyEvent
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat
import com.example.ringbt_01.MainActivity
import com.example.ringbt_01.debug.DebugLogger

/**
 * Servizio foreground che gestisce la cascata di chiamate d'emergenza SOS.
 *
 * Logica delle chiamate:
 * 1. Viene chiamato il primo contatto con vivavoce automatico.
 * 2. Se suona libero e la persona NON risponde entro 20 secondi:
 *    - L'app tenta la chiusura forzata della chiamata.
 *    - Appena la linea torna IDLE (riaggancio locale o del gestore telefonico),
 *      si passa al contatto successivo della cascata.
 * 3. Se la persona chiude (rifiuta) o la segreteria chiude la chiamata:
 *    - Arriva immediatamente IDLE, l'app avanza al contatto successivo.
 * 4. Se la persona RISPONDE:
 *    - L'utente (o il soccorritore) può premere "✅ Ha Risposto" nella notifica o nell'app:
 *      il timer di 20s viene cancellato e la chiamata prosegue SENZA LIMITI DI TEMPO.
 *    - Quando la conversazione si conclude (riaggancio finale), la sequenza SOS
 *      termina con successo (scopo raggiunto).
 */
class EmergencyCallService : Service() {

    private enum class CallState {
        IDLE,       // Nessuna chiamata in corso
        DIALING,    // Intent inviato, in attesa del primo OFFHOOK
        RINGING,    // Telefono in squillo/composizione, timer 20s attivo
        ANSWERED,   // Chiamata risposta, nessun limite di tempo
        ENDING      // Chiusura in corso, in attesa di IDLE prima del prossimo contatto
    }

    companion object {
        private const val TAG = "EmergencyCallService"
        private const val CHANNEL_ID = "EMERGENCY_CALL_CHANNEL"
        private const val NOTIFICATION_ID = 2

        // Timeout di 20 secondi per mancata risposta / squillo a vuoto
        private const val NO_ANSWER_TIMEOUT_MS = 20_000L

        // Timeout se il modem non passa in OFFHOOK entro 15 secondi dall'invio dell'intent
        private const val DIALING_TIMEOUT_MS = 15_000L

        // Pausa di sicurezza tra una chiamata e l'altra (per far stabilizzare il modem cellulare)
        private const val DELAY_BETWEEN_CALLS_MS = 3_000L

        // Timeout di sicurezza massimo per il rilascio della linea dopo richiesta di chiusura
        private const val DISCONNECT_MAX_WAIT_MS = 12_000L

        const val EXTRA_CONTACTS = "extra_contacts"
        const val ACTION_MARK_ANSWERED = "com.example.ringbt_01.ACTION_MARK_ANSWERED"
        const val ACTION_SKIP_TO_NEXT = "com.example.ringbt_01.ACTION_SKIP_TO_NEXT"

        @Volatile
        var isRunning = false
            private set

        fun createIntent(context: Context, contacts: List<String>): Intent {
            return Intent(context, EmergencyCallService::class.java).apply {
                putStringArrayListExtra(EXTRA_CONTACTS, ArrayList(contacts))
            }
        }
    }

    private var contacts: List<String> = emptyList()
    private var currentContactIndex = 0
    private var callState = CallState.IDLE
    private var callGeneration = 0
    private var hasSeenOffhook = false

    private var cpuWakeLock: PowerManager.WakeLock? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    private var noAnswerTimeoutRunnable: Runnable? = null
    private var dialingTimeoutRunnable: Runnable? = null
    private var disconnectTimeoutRunnable: Runnable? = null
    private var nextCallRunnable: Runnable? = null

    @Suppress("DEPRECATION")
    private var phoneStateListener: PhoneStateListener? = null
    private var telephonyCallbackRef: Any? = null

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "onCreate")
        createNotificationChannel()
        setupTelephonyListener()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d(TAG, "onStartCommand: action=${intent?.action}")

        // Azione: Interlocutore ha risposto (annulla timeout 20s)
        if (intent?.action == ACTION_MARK_ANSWERED) {
            handleCallAnswered()
            return START_NOT_STICKY
        }

        // Azione: Salta manualmente al prossimo contatto
        if (intent?.action == ACTION_SKIP_TO_NEXT) {
            Log.d(TAG, "Azione manuale: Salta al prossimo contatto")
            requestDisconnectAndAdvance("Avanzamento manuale richiesto", callGeneration)
            return START_NOT_STICKY
        }

        if (isRunning) {
            Log.w(TAG, "EmergencyCallService già in esecuzione: nuova richiesta ignorata")
            return START_NOT_STICKY
        }

        val contactList = intent?.getStringArrayListExtra(EXTRA_CONTACTS)
        if (contactList.isNullOrEmpty()) {
            Log.e(TAG, "Lista contatti vuota, arresto servizio")
            finishService()
            return START_NOT_STICKY
        }

        contacts = contactList.filter { it.isNotBlank() }
        if (contacts.isEmpty()) {
            Log.e(TAG, "Nessun contatto valido dopo il filtro, arresto servizio")
            finishService()
            return START_NOT_STICKY
        }

        isRunning = true
        acquireCpuWakeLock()
        currentContactIndex = 0

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    NOTIFICATION_ID,
                    createNotification("Avvio sequenza chiamate SOS..."),
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(NOTIFICATION_ID, createNotification("Avvio sequenza chiamate SOS..."))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Errore startForeground in EmergencyCallService", e)
        }
        // Risveglia subito lo schermo fisicamente
        wakeUpScreen()

        // Pausa di 1.2 secondi per permettere al pannello display di accendersi fisicamente
        // e al modem cellulare di uscire dalla modalità di riposo profondo
        mainHandler.postDelayed({
            if (isRunning) {
                executeCallStep(0)
            }
        }, 1200L)

        return START_NOT_STICKY
    }

    private fun executeCallStep(index: Int) {
        if (index >= contacts.size) {
            Log.d(TAG, "Tutti i contatti ($index/${contacts.size}) sono stati chiamati. Sequenza completata.")
            showToast("Sequenza chiamate SOS completata (nessuna risposta)")
            finishService()
            return
        }

        callGeneration++
        val gen = callGeneration

        currentContactIndex = index
        val rawPhoneNumber = contacts[index]
        val cleanNumber = rawPhoneNumber.trim().replace(" ", "").replace("-", "")

        Log.d(TAG, "═══════════════════════════════════════════════════════")
        Log.d(TAG, "📞 CHIAMATA SOS ${index + 1}/${contacts.size} a $cleanNumber (gen=$gen)")
        Log.d(TAG, "═══════════════════════════════════════════════════════")
        DebugLogger.log("CALL", "📞 Chiamata SOS ${index + 1}/${contacts.size} a $cleanNumber (gen=$gen)")

        callState = CallState.DIALING
        hasSeenOffhook = false

        updateNotification("Chiamata a $cleanNumber (${index + 1}/${contacts.size}) - Squillo...")
        showToast("📞 Chiamata SOS a: $cleanNumber (${index + 1}/${contacts.size})")

        // 1. Accendi schermo e attiva vivavoce
        wakeUpScreen()
        enableSpeakerphone()

        // 2. Invia la chiamata di sistema
        makePhoneCall(cleanNumber)

        // 3. Safety retry per il caso schermo spento/bloccato:
        // Se dopo 2.5 secondi il modem non è ancora passato in OFFHOOK,
        // ripete l'invio dell'intent a schermo ormai sicuramente attivo
        mainHandler.postDelayed({
            if (gen == callGeneration && callState == CallState.DIALING && !hasSeenOffhook) {
                Log.w(TAG, "⏱️ Nessun OFFHOOK dopo 2.5s (schermo in risveglio): ripeto ACTION_CALL per $cleanNumber")
                DebugLogger.log("CALL", "⏱️ Safety Retry: ripetizione ACTION_CALL per $cleanNumber")
                wakeUpScreen()
                makePhoneCall(cleanNumber)
            }
        }, 2500L)

        // 4. Avvia timeout di sicurezza composizione (se non va in OFFHOOK entro 15s)
        startDialingTimeout(gen)
    }

    @SuppressLint("MissingPermission")
    private fun makePhoneCall(phoneNumber: String) {
        val callUri = Uri.parse("tel:$phoneNumber")
        try {
            val callIntent = Intent(Intent.ACTION_CALL, callUri).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_CLEAR_TOP or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                val options = ActivityOptions.makeBasic().apply {
                    setPendingIntentBackgroundActivityStartMode(ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED)
                }
                val pi = PendingIntent.getActivity(
                    this,
                    callGeneration,
                    callIntent,
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                pi.send(this, 0, null, null, null, null, options.toBundle())
            } else {
                startActivity(callIntent)
            }

            Log.d(TAG, "Intent ACTION_CALL inviato con successo per $phoneNumber")
            DebugLogger.log("CALL", "Intent ACTION_CALL inviato a $phoneNumber")

            // Riapplica il vivavoce a +1.5s e +3s per contrastare eventuali reset dell'app telefono
            mainHandler.postDelayed({ enableSpeakerphone() }, 1500L)
            mainHandler.postDelayed({ enableSpeakerphone() }, 3000L)
        } catch (e: Exception) {
            Log.e(TAG, "Errore ACTION_CALL per $phoneNumber, tentativo fallback ACTION_DIAL", e)
            DebugLogger.log("CALL", "❌ Errore ACTION_CALL: ${e.message}")
            try {
                val dialIntent = Intent(Intent.ACTION_DIAL, callUri).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_CLEAR_TOP or
                            Intent.FLAG_ACTIVITY_SINGLE_TOP
                }
                startActivity(dialIntent)
            } catch (e2: Exception) {
                Log.e(TAG, "Errore anche con ACTION_DIAL per $phoneNumber", e2)
                onCallEnded("Impossibile avviare la chiamata", callGeneration)
            }
        }
    }

    private fun handleCallStateChange(state: Int) {
        val gen = callGeneration
        Log.d(TAG, "📱 Telephony state=$state (callState=$callState, gen=$gen, hasSeenOffhook=$hasSeenOffhook)")

        when (state) {
            TelephonyManager.CALL_STATE_OFFHOOK -> {
                if (callState == CallState.DIALING) {
                    hasSeenOffhook = true
                    callState = CallState.RINGING
                    Log.d(TAG, "→ OFFHOOK ricevuto. Stato: RINGING. Avvio timer mancata risposta 20s.")
                    DebugLogger.log("CALL", "→ OFFHOOK ricevuto (chiamata in squillo/attiva). Timer 20s avviato.")

                    cancelDialingTimeout()

                    val currentPhone = contacts.getOrNull(currentContactIndex) ?: ""
                    updateNotification("In chiamata con $currentPhone (${currentContactIndex + 1}/${contacts.size})")

                    // Avvia timer di 20 secondi: se nessuno risponde o chiude prima, chiude la chiamata
                    startNoAnswerTimeout(gen)
                } else {
                    Log.d(TAG, "OFFHOOK in stato $callState (invariato)")
                }
            }

            TelephonyManager.CALL_STATE_IDLE -> {
                Log.d(TAG, "📱 IDLE ricevuto (callState=$callState, hasSeenOffhook=$hasSeenOffhook, gen=$gen)")
                DebugLogger.log("CALL", "📱 IDLE ricevuto (stato: $callState)")

                // Ignora l'IDLE iniziale precedente all'avvio della chiamata corrente
                if (!hasSeenOffhook && callState == CallState.DIALING) {
                    Log.d(TAG, "IDLE ignorato: la chiamata corrente non è ancora partita.")
                    return
                }

                when (callState) {
                    CallState.RINGING, CallState.ENDING -> {
                        // La chiamata si è chiusa (mancata risposta, rifiuto, segreteria chiusa, o chiusura locale)
                        Log.d(TAG, "→ IDLE dopo RINGING/ENDING: Chiamata terminata. Procedo con il prossimo contatto.")
                        onCallEnded("Chiamata terminata (IDLE)", gen)
                    }

                    CallState.ANSWERED -> {
                        // L'interlocutore aveva risposto e ora la conversazione si è conclusa.
                        // La sequenza SOS ha raggiunto il suo scopo con successo!
                        Log.d(TAG, "→ IDLE dopo ANSWERED: Conversazione SOS completata con successo!")
                        showToast("✅ Chiamata di soccorso completata con successo!")
                        finishService()
                    }

                    CallState.DIALING -> {
                        if (hasSeenOffhook) {
                            Log.d(TAG, "→ IDLE durante DIALING con offhook: chiamata caduta rapidamente.")
                            onCallEnded("Chiamata caduta", gen)
                        }
                    }

                    else -> {
                        Log.d(TAG, "IDLE ignorato in stato $callState")
                    }
                }
            }

            TelephonyManager.CALL_STATE_RINGING -> {
                Log.d(TAG, "📱 RINGING (chiamata in arrivo esterna)")
            }
        }
    }

    /**
     * Timeout di 20 secondi: se la chiamata sta ancora squillando e nessuno ha risposto
     * (e nessuno ha chiuso), chiude la chiamata e passa al prossimo contatto.
     */
    private fun startNoAnswerTimeout(gen: Int) {
        cancelNoAnswerTimeout()
        noAnswerTimeoutRunnable = Runnable {
            if (gen != callGeneration) return@Runnable
            if (callState == CallState.RINGING) {
                Log.d(TAG, "⏱️ TIMEOUT 20s SQUILLO SENZA RISPOSTA. Chiusura e passaggio al prossimo...")
                DebugLogger.log("CALL", "⏱️ Timeout 20s mancata risposta: chiusura forzata...")
                showToast("⏱️ Nessuna risposta (20s): chiudo e chiamo il prossimo...")
                requestDisconnectAndAdvance("Timeout 20s mancata risposta", gen)
            }
        }
        mainHandler.postDelayed(noAnswerTimeoutRunnable!!, NO_ANSWER_TIMEOUT_MS)
        Log.d(TAG, "⏱️ Timer 20s mancata risposta avviato per gen=$gen")
    }

    private fun cancelNoAnswerTimeout() {
        noAnswerTimeoutRunnable?.let {
            mainHandler.removeCallbacks(it)
            Log.d(TAG, "⏱️ Timer mancata risposta cancellato")
        }
        noAnswerTimeoutRunnable = null
    }

    /**
     * Segna la chiamata come risposta: annulla il timeout di 20s e lascia
     * la chiamata attiva senza alcun limite di tempo.
     */
    private fun handleCallAnswered() {
        if (!isRunning || (callState != CallState.DIALING && callState != CallState.RINGING)) {
            Log.d(TAG, "handleCallAnswered ignorato: stato attuale=$callState")
            return
        }

        callState = CallState.ANSWERED
        cancelAllTimers()
        enableSpeakerphone()

        val currentPhone = contacts.getOrNull(currentContactIndex) ?: ""
        Log.d(TAG, "═══════════════════════════════════════════════════════")
        Log.d(TAG, "✅ CHIAMATA RISPOSTA con $currentPhone")
        Log.d(TAG, "   Conversazione attiva SENZA LIMITI DI TEMPO")
        Log.d(TAG, "═══════════════════════════════════════════════════════")
        DebugLogger.log("CALL", "✅ RISPOSTA da $currentPhone. Conversazione attiva senza limiti.")

        updateNotification("✅ In conversazione con $currentPhone (${currentContactIndex + 1}/${contacts.size})")
        showToast("✅ Chiamata SOS risposta! Nessun limite di tempo.")
    }

    private fun startDialingTimeout(gen: Int) {
        cancelDialingTimeout()
        dialingTimeoutRunnable = Runnable {
            if (gen != callGeneration) return@Runnable
            if (callState == CallState.DIALING && !hasSeenOffhook) {
                Log.w(TAG, "⏱️ Timeout composizione: nessun OFFHOOK ricevuto in ${DIALING_TIMEOUT_MS}ms")
                showToast("⚠️ Chiamata non partita, passo al prossimo...")
                onCallEnded("Timeout composizione", gen)
            }
        }
        mainHandler.postDelayed(dialingTimeoutRunnable!!, DIALING_TIMEOUT_MS)
    }

    private fun cancelDialingTimeout() {
        dialingTimeoutRunnable?.let { mainHandler.removeCallbacks(it) }
        dialingTimeoutRunnable = null
    }

    /**
     * Richiede la chiusura della chiamata attiva e prepara l'avanzamento al prossimo contatto.
     */
    private fun requestDisconnectAndAdvance(reason: String, gen: Int) {
        if (gen != callGeneration) return
        if (callState != CallState.DIALING && callState != CallState.RINGING) {
            Log.d(TAG, "requestDisconnectAndAdvance ignorato: stato=$callState")
            return
        }

        Log.d(TAG, "$reason: richiesta chiusura chiamata (gen=$gen)")
        callState = CallState.ENDING
        cancelNoAnswerTimeout()
        cancelDialingTimeout()

        updateNotification("Chiusura chiamata in corso... Prossimo contatto a breve")

        // Timeout di sicurezza massimo per il rilascio della linea (se la rete ritarda l'IDLE)
        cancelDisconnectTimeout()
        disconnectTimeoutRunnable = Runnable {
            if (gen != callGeneration) return@Runnable
            if (callState == CallState.ENDING) {
                Log.w(TAG, "Linea non tornata in IDLE entro ${DISCONNECT_MAX_WAIT_MS}ms. Avanzamento forzato.")
                onCallEnded("Timeout attesa linea libera", gen)
            }
        }
        mainHandler.postDelayed(disconnectTimeoutRunnable!!, DISCONNECT_MAX_WAIT_MS)

        hangUpCurrentCall()
    }

    @SuppressLint("MissingPermission")
    private fun hangUpCurrentCall() {
        Log.d(TAG, "Tentativo di riagganciare la chiamata attiva...")

        // 1. TelecomManager.endCall() (Android 9+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try {
                val telecomManager = getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
                if (telecomManager != null) {
                    @Suppress("DEPRECATION")
                    val result = telecomManager.endCall()
                    Log.d(TAG, "TelecomManager.endCall() → $result")
                    if (result) return
                }
            } catch (e: Exception) {
                Log.d(TAG, "TelecomManager.endCall() non riuscito: ${e.message}")
            }
        }

        // 2. Headset Hook simulation (Media key per riagganciare)
        try {
            val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val eventDown = KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_HEADSETHOOK)
            val eventUp = KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_HEADSETHOOK)
            audioManager.dispatchMediaKeyEvent(eventDown)
            audioManager.dispatchMediaKeyEvent(eventUp)
            Log.d(TAG, "dispatchMediaKeyEvent KEYCODE_HEADSETHOOK inviato")
        } catch (e: Exception) {
            Log.d(TAG, "dispatchMediaKeyEvent non riuscito: ${e.message}")
        }

        // 3. Fallback Reflection su ITelephony
        try {
            val telephonyManager = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            val getITelephony = telephonyManager.javaClass.getDeclaredMethod("getITelephony")
            getITelephony.isAccessible = true
            val iTelephony = getITelephony.invoke(telephonyManager)
            if (iTelephony != null) {
                val endCall = iTelephony.javaClass.getDeclaredMethod("endCall")
                val res = endCall.invoke(iTelephony)
                Log.d(TAG, "ITelephony.endCall() reflection → $res")
            }
        } catch (e: Exception) {
            Log.d(TAG, "ITelephony reflection non riuscito: ${e.message}")
        }
    }

    private fun onCallEnded(reason: String, gen: Int) {
        if (gen != callGeneration) {
            Log.d(TAG, "onCallEnded ignorato: gen=$gen ≠ current=$callGeneration")
            return
        }
        if (callState == CallState.IDLE) return

        Log.d(TAG, "onCallEnded: $reason (gen=$gen). Programmazione prossimo contatto...")
        callState = CallState.IDLE
        cancelAllTimers()

        val nextIndex = currentContactIndex + 1
        if (nextIndex < contacts.size) {
            updateNotification("Prossima chiamata a ${contacts[nextIndex]} tra 3 secondi...")
            nextCallRunnable = Runnable {
                executeCallStep(nextIndex)
            }
            mainHandler.postDelayed(nextCallRunnable!!, DELAY_BETWEEN_CALLS_MS)
        } else {
            Log.d(TAG, "Tutti i contatti chiamati senza risposta. Fine sequenza.")
            showToast("Sequenza SOS completata — nessuna risposta dai contatti")
            finishService()
        }
    }

    private fun cancelAllTimers() {
        cancelNoAnswerTimeout()
        cancelDialingTimeout()
        cancelDisconnectTimeout()
        nextCallRunnable?.let { mainHandler.removeCallbacks(it) }
        nextCallRunnable = null
    }

    private fun cancelDisconnectTimeout() {
        disconnectTimeoutRunnable?.let { mainHandler.removeCallbacks(it) }
        disconnectTimeoutRunnable = null
    }

    private fun enableSpeakerphone() {
        try {
            val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            audioManager.mode = AudioManager.MODE_IN_CALL
            @Suppress("DEPRECATION")
            audioManager.isSpeakerphoneOn = true
            Log.d(TAG, "🔊 Vivavoce attivato (isSpeakerphoneOn = true)")
        } catch (e: Exception) {
            Log.e(TAG, "Errore abilitazione vivavoce", e)
        }
    }

    private fun wakeUpScreen() {
        try {
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!powerManager.isInteractive) {
                @Suppress("DEPRECATION")
                val screenLock = powerManager.newWakeLock(
                    PowerManager.SCREEN_BRIGHT_WAKE_LOCK or
                    PowerManager.ACQUIRE_CAUSES_WAKEUP or
                    PowerManager.ON_AFTER_RELEASE,
                    "RingBT:EmergencyScreenWake"
                )
                screenLock.acquire(6000L)
                Log.d(TAG, "Schermo risvegliato per chiamata SOS")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Errore risveglio schermo", e)
        }
    }

    private fun acquireCpuWakeLock() {
        try {
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            cpuWakeLock = powerManager.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "RingBT:EmergencyCpuWakeLock"
            ).apply {
                acquire(10 * 60 * 1000L)
            }
            Log.d(TAG, "CPU WakeLock acquisito")
        } catch (e: Exception) {
            Log.e(TAG, "Errore acquisizione CPU WakeLock", e)
        }
    }

    private fun releaseCpuWakeLock() {
        cpuWakeLock?.let {
            if (it.isHeld) {
                try {
                    it.release()
                    Log.d(TAG, "CPU WakeLock rilasciato")
                } catch (e: Exception) {
                    Log.e(TAG, "Errore rilascio CPU WakeLock", e)
                }
            }
        }
        cpuWakeLock = null
    }

    private fun setupTelephonyListener() {
        val telephonyManager = getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
        if (telephonyManager == null) {
            Log.w(TAG, "TelephonyManager non disponibile su questo dispositivo")
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            setupTelephonyCallbackS(telephonyManager)
        } else {
            setupLegacyPhoneStateListener(telephonyManager)
        }
    }

    @RequiresApi(Build.VERSION_CODES.S)
    private fun setupTelephonyCallbackS(telephonyManager: TelephonyManager) {
        val callback = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
            override fun onCallStateChanged(state: Int) {
                handleCallStateChange(state)
            }
        }
        telephonyCallbackRef = callback
        telephonyManager.registerTelephonyCallback(mainExecutor, callback)
        Log.d(TAG, "TelephonyCallback registrato (API 31+)")
    }

    @Suppress("DEPRECATION")
    private fun setupLegacyPhoneStateListener(telephonyManager: TelephonyManager) {
        val listener = object : PhoneStateListener() {
            override fun onCallStateChanged(state: Int, phoneNumber: String?) {
                handleCallStateChange(state)
            }
        }
        phoneStateListener = listener
        telephonyManager.listen(listener, PhoneStateListener.LISTEN_CALL_STATE)
        Log.d(TAG, "PhoneStateListener registrato (legacy)")
    }

    private fun unregisterTelephonyListener() {
        val telephonyManager = getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
            ?: return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            telephonyCallbackRef?.let {
                try {
                    telephonyManager.unregisterTelephonyCallback(it as TelephonyCallback)
                } catch (e: Exception) {
                    Log.e(TAG, "Errore unregister TelephonyCallback", e)
                }
            }
            telephonyCallbackRef = null
        } else {
            @Suppress("DEPRECATION")
            phoneStateListener?.let {
                try {
                    telephonyManager.listen(it, PhoneStateListener.LISTEN_NONE)
                } catch (e: Exception) {
                    Log.e(TAG, "Errore unregister PhoneStateListener", e)
                }
            }
            phoneStateListener = null
        }
    }

    private fun finishService() {
        Log.d(TAG, "finishService: arresto EmergencyCallService")
        isRunning = false
        callState = CallState.IDLE

        cancelAllTimers()
        unregisterTelephonyListener()
        releaseCpuWakeLock()

        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun showToast(message: String) {
        if (!com.example.ringbt_01.debug.DebugConfig.showDebugToasts) return
        mainHandler.post {
            Toast.makeText(applicationContext, message, Toast.LENGTH_SHORT).show()
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Chiamate d'Emergenza SOS",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifiche ad alta priorità per le chiamate d'emergenza SOS"
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                enableVibration(true)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(content: String): Notification {
        val notificationIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, notificationIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val answeredIntent = Intent(this, EmergencyCallService::class.java).apply {
            action = ACTION_MARK_ANSWERED
        }
        val answeredPendingIntent = PendingIntent.getService(
            this, 1, answeredIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val skipIntent = Intent(this, EmergencyCallService::class.java).apply {
            action = ACTION_SKIP_TO_NEXT
        }
        val skipPendingIntent = PendingIntent.getService(
            this, 2, skipIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("⚠️ SOS RING - Emergenza Chiamate")
            .setContentText(content)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentIntent(pendingIntent)
            .setFullScreenIntent(pendingIntent, true)
            .addAction(
                android.R.drawable.ic_menu_call,
                "✅ Ha Risposto (Nessun limite)",
                answeredPendingIntent
            )
            .addAction(
                android.R.drawable.ic_media_next,
                "⏭️ Passa al prossimo",
                skipPendingIntent
            )
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(content: String) {
        val notification = createNotification(content)
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, notification)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        Log.d(TAG, "onDestroy")
        finishService()
        super.onDestroy()
    }
}
