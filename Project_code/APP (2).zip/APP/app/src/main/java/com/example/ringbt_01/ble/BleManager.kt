package com.example.ringbt_01.ble

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.*

@SuppressLint("MissingPermission")
class BleManager(private val context: Context) {

    private val bluetoothManager: BluetoothManager? = try {
        context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    } catch (e: Exception) {
        null
    }

    private val adapter: BluetoothAdapter?
        get() = try {
            bluetoothManager?.adapter
        } catch (e: Exception) {
            null
        }

    private var bluetoothGatt: BluetoothGatt? = null

    private val _connectionState = MutableStateFlow(BluetoothProfile.STATE_DISCONNECTED)
    val connectionState: StateFlow<Int> = _connectionState

    private val _discoveredDevices = MutableStateFlow<List<BluetoothDevice>>(emptyList())
    val discoveredDevices: StateFlow<List<BluetoothDevice>> = _discoveredDevices

    private val _isBluetoothEnabled = MutableStateFlow(isBluetoothEnabled())
    val isBluetoothEnabled: StateFlow<Boolean> = _isBluetoothEnabled

    private val _receivedData = MutableStateFlow("")
    val receivedData: StateFlow<String> = _receivedData

    // Common UUIDs for UART-like communication
    private val UART_SERVICE_UUID = UUID.fromString("6E400001-B5A3-F393-E0A9-E50E24DCCA9E")
    private val UART_RX_CHAR_UUID = UUID.fromString("6E400003-B5A3-F393-E0A9-E50E24DCCA9E")

    private var isScanning = false

    fun isBluetoothEnabled(): Boolean = try {
        adapter?.isEnabled ?: false
    } catch (e: Exception) {
        false
    }

    fun startScanning() {
        if (!isBluetoothEnabled()) {
            _isBluetoothEnabled.value = false
            return
        }
        _isBluetoothEnabled.value = true
        _discoveredDevices.value = emptyList()
        
        try {
            val currentAdapter = adapter ?: return
            val scanner = currentAdapter.bluetoothLeScanner
            if (scanner == null) {
                Log.e("BleManager", "BluetoothLeScanner is null")
                return
            }

            if (isScanning) {
                stopScanning()
            }

            try {
                currentAdapter.cancelDiscovery()
            } catch (e: Exception) {
                Log.w("BleManager", "cancelDiscovery error ignored", e)
            }

            val settings = android.bluetooth.le.ScanSettings.Builder()
                .setScanMode(android.bluetooth.le.ScanSettings.SCAN_MODE_LOW_LATENCY)
                .build()

            Log.d("BleManager", "Starting BLE Scan (LOW_LATENCY)...")
            scanner.startScan(null, settings, scanCallback)
            isScanning = true
        } catch (e: SecurityException) {
            Log.e("BleManager", "Missing Bluetooth permission for scanning", e)
        } catch (e: Exception) {
            Log.e("BleManager", "Failed to start scan", e)
        }
    }

    fun stopScanning() {
        if (!isScanning) return
        Log.d("BleManager", "Stopping BLE Scan")
        try {
            adapter?.bluetoothLeScanner?.stopScan(scanCallback)
        } catch (e: Exception) {
            Log.e("BleManager", "Error stopping scan", e)
        }
        isScanning = false
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            val deviceName = try { device.name ?: "Unknown" } catch (e: SecurityException) { "Unknown" }
            Log.d("BleManager", "Discovered: $deviceName (${device.address})")
            if (device.name != null && !_discoveredDevices.value.any { it.address == device.address }) {
                _discoveredDevices.value = _discoveredDevices.value + device
            }
        }
    }

    private var lastUsedAddress: String? = null
    private var isManualDisconnect = false

    fun connect(address: String) {
        lastUsedAddress = address
        isManualDisconnect = false
        try {
            val currentAdapter = adapter
            if (currentAdapter == null) {
                Log.e("BleManager", "BluetoothAdapter non disponibile")
                _connectionState.value = BluetoothProfile.STATE_DISCONNECTED
                return
            }

            if (bluetoothGatt != null) {
                try {
                    bluetoothGatt?.disconnect()
                    bluetoothGatt?.close()
                } catch (e: Exception) {
                    Log.w("BleManager", "Error closing old gatt", e)
                }
                bluetoothGatt = null
            }
            
            val device = currentAdapter.getRemoteDevice(address)
            val devName = try { device.name ?: "Unknown" } catch (e: SecurityException) { "Unknown" }
            Log.d("BleManager", "Connessione a $devName ($address) in corso...")
            
            // Forziamo TRANSPORT_LE per Android 6.0+
            bluetoothGatt = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                device.connectGatt(context, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
            } else {
                device.connectGatt(context, false, gattCallback)
            }
        } catch (e: SecurityException) {
            Log.e("BleManager", "Missing Bluetooth permission for connectGatt", e)
            _connectionState.value = BluetoothProfile.STATE_DISCONNECTED
        } catch (e: Exception) {
            Log.e("BleManager", "Errore durante la connectGatt", e)
            _connectionState.value = BluetoothProfile.STATE_DISCONNECTED
        }
    }

    fun disconnect() {
        Log.d("BleManager", "Richiesta disconnessione manuale")
        isManualDisconnect = true
        try {
            bluetoothGatt?.disconnect()
            bluetoothGatt?.close()
        } catch (e: Exception) {
            Log.e("BleManager", "Error during disconnect", e)
        }
        bluetoothGatt = null
        _connectionState.value = BluetoothProfile.STATE_DISCONNECTED
    }

    fun clearData() {
        _receivedData.value = ""
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            Log.d("BleManager", "onConnectionStateChange: status=$status, newState=$newState")
            _connectionState.value = newState
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                Log.d("BleManager", "Connected, discovering services...")
                gatt.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                Log.d("BleManager", "Disconnected, status: $status")
                gatt.close()
                if (gatt == bluetoothGatt) {
                    bluetoothGatt = null
                }
                
                // Riconnessione Automatica se non è una disconnessione manuale
                if (!isManualDisconnect && lastUsedAddress != null) {
                    Log.d("BleManager", "Tentativo di riconnessione automatica tra 5 secondi...")
                    android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                        if (!isManualDisconnect && lastUsedAddress != null) {
                            connect(lastUsedAddress!!)
                        }
                    }, 5000)
                }
            }
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            Log.d("BleManager", "onServicesDiscovered status: $status")
            if (status == BluetoothGatt.GATT_SUCCESS) {
                var foundAnyUart = false
                
                gatt.services.forEach { service ->
                    Log.d("BleManager", "Service: ${service.uuid}")
                    service.characteristics.forEach { char ->
                        val props = char.properties
                        val isNotify = (props and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0
                        Log.d("BleManager", "  Char: ${char.uuid} | Notify: $isNotify")
                        
                        // Se è l'UUID che cerchiamo O se è una qualsiasi caratteristica con Notify
                        if (char.uuid == UART_RX_CHAR_UUID || (isNotify && !foundAnyUart)) {
                            Log.d("BleManager", "Abilitazione notifiche per: ${char.uuid}")
                            gatt.setCharacteristicNotification(char, true)
                            val descriptor = char.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"))
                            if (descriptor != null) {
                                descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                                gatt.writeDescriptor(descriptor)
                                foundAnyUart = true
                            }
                        }
                    }
                }
                
                if (!foundAnyUart) {
                    Log.e("BleManager", "Nessuna caratteristica UART o Notify trovata!")
                }
            }
        }

        @Suppress("DEPRECATION")
        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            val bytes = characteristic.value ?: return
            processReceivedBytes(bytes)
        }

        // Support for newer Android versions (API 33+)
        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            processReceivedBytes(value)
        }
    }

    fun simulateIncomingData(data: String) {
        Log.d("BleManager", "[SIMULAZIONE TEST] Ricevuto pacchetto simulato: '$data'")
        processReceivedBytes(data.toByteArray())
    }

    private fun processReceivedBytes(bytes: ByteArray) {
        val data = bytes.decodeToString()
        Log.d("BleManager", "Received raw packet: $data")
        
        // Append to current buffer
        val currentBuffer = _receivedData.value
        val newBuffer = currentBuffer + data
        
        // Limit buffer size
        _receivedData.value = if (newBuffer.length > 200) {
            newBuffer.takeLast(100)
        } else {
            newBuffer
        }
        Log.d("BleManager", "Current Buffer: ${_receivedData.value}")
    }
}
