package com.example.ringbt_01.debug

import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Configurazione globale per i debug popup (Toast) e opzioni di sviluppo.
 */
object DebugConfig {
    @Volatile
    var showDebugToasts: Boolean = false
}

/**
 * Logger in-memory temporaneo per stress testing e monitoraggio in tempo reale.
 */
object DebugLogger {
    private val _logs = MutableStateFlow<List<String>>(emptyList())
    val logs: StateFlow<List<String>> = _logs

    fun log(tag: String, message: String) {
        Log.d(tag, message)
        val time = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date())
        val entry = "[$time][$tag] $message"
        _logs.value = (_logs.value + entry).takeLast(150)
    }

    fun clear() {
        _logs.value = emptyList()
    }
}
