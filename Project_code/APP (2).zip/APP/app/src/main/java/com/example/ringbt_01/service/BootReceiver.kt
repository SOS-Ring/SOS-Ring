package com.example.ringbt_01.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == "android.intent.action.QUICKBOOT_POWERON") {
            Log.d("BootReceiver", "Telefono riavviato. Avvio RingBT Service...")
            try {
                val serviceIntent = Intent(context, BLEForegroundService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(serviceIntent)
                } else {
                    context.startService(serviceIntent)
                }
            } catch (e: Exception) {
                // Android 14+ può lanciare ForegroundServiceStartNotAllowedException
                // se le restrizioni di background non consentono l'avvio.
                Log.e("BootReceiver", "Impossibile avviare il servizio BLE dal boot", e)
            }
        }
    }
}
