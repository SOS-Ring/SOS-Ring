package com.example.ringbt_01.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.ringbt_01.debug.DebugConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "settings")

data class AppSettings(
    val contact1: String = "",
    val contact2: String = "",
    val contact3: String = "",
    val smsMessage: String = "Aiuto! Sono in difficoltà. Ecco la mia posizione: ",
    val sosRingAddress: String = "",
    val appTheme: String = "SYSTEM", // SYSTEM, DARK_RED, DARK_YELLOW, DARK_GREEN, DARK_BLUE, LIGHT_WHITE
    val labPin: String = "1234",
    val showDebugToasts: Boolean = false
)

class SettingsRepository(private val context: Context) {

    private object PreferencesKeys {
        val CONTACT1 = stringPreferencesKey("contact1")
        val CONTACT2 = stringPreferencesKey("contact2")
        val CONTACT3 = stringPreferencesKey("contact3")
        val SMS_MESSAGE = stringPreferencesKey("sms_message")
        val SOS_RING_ADDRESS = stringPreferencesKey("sos_ring_address")
        val APP_THEME = stringPreferencesKey("app_theme")
        val LAB_PIN = stringPreferencesKey("lab_pin")
        val SHOW_DEBUG_TOASTS = booleanPreferencesKey("show_debug_toasts")
    }

    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { preferences ->
        val debugToasts = preferences[PreferencesKeys.SHOW_DEBUG_TOASTS] ?: false
        DebugConfig.showDebugToasts = debugToasts

        AppSettings(
            contact1 = preferences[PreferencesKeys.CONTACT1] ?: "",
            contact2 = preferences[PreferencesKeys.CONTACT2] ?: "",
            contact3 = preferences[PreferencesKeys.CONTACT3] ?: "",
            smsMessage = preferences[PreferencesKeys.SMS_MESSAGE] ?: "Aiuto! Sono in difficoltà. Ecco la mia posizione: ",
            sosRingAddress = preferences[PreferencesKeys.SOS_RING_ADDRESS] ?: "",
            appTheme = preferences[PreferencesKeys.APP_THEME] ?: "SYSTEM",
            labPin = preferences[PreferencesKeys.LAB_PIN] ?: "1234",
            showDebugToasts = debugToasts
        )
    }

    suspend fun updateContacts(c1: String, c2: String, c3: String) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.CONTACT1] = c1
            preferences[PreferencesKeys.CONTACT2] = c2
            preferences[PreferencesKeys.CONTACT3] = c3
        }
    }

    suspend fun updateSmsMessage(message: String) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.SMS_MESSAGE] = message
        }
    }

    suspend fun updateSosRingAddress(address: String) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.SOS_RING_ADDRESS] = address
        }
    }

    suspend fun updateAppTheme(theme: String) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.APP_THEME] = theme
        }
    }

    suspend fun updateLabPin(pin: String) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.LAB_PIN] = pin
        }
    }

    suspend fun updateShowDebugToasts(enabled: Boolean) {
        DebugConfig.showDebugToasts = enabled
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.SHOW_DEBUG_TOASTS] = enabled
        }
    }
}
