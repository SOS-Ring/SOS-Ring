package com.example.ringbt_01.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Help
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ringbt_01.MainViewModel

sealed class Screen(val route: String, val label: String, val icon: ImageVector) {
    object Home : Screen("home", "Status", Icons.Default.Home)
    object Contacts : Screen("contacts", "Contatti", Icons.Default.Contacts)
    object Settings : Screen("settings", "Impostazioni", Icons.Default.Settings)
    object Help : Screen("help", "Guida", Icons.Default.Help)
    object TestLab : Screen("test_lab", "Test Lab", Icons.Default.Build)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: MainViewModel) {
    val navController = rememberNavController()
    val settings by viewModel.settings.collectAsState()

    // Solo le 4 schermate standard nella barra di navigazione
    val items = listOf(Screen.Home, Screen.Contacts, Screen.Settings, Screen.Help)
    var selectedItem by remember { mutableStateOf(0) }

    // Gestione sblocco segreto: 4 click su Guida
    var guideClickCount by remember { mutableStateOf(0) }
    var lastGuideClickTime by remember { mutableStateOf(0L) }
    var showPinDialog by remember { mutableStateOf(false) }

    val onGuideSecretTap = {
        val now = System.currentTimeMillis()
        if (now - lastGuideClickTime < 1500L) {
            guideClickCount++
        } else {
            guideClickCount = 1
        }
        lastGuideClickTime = now

        if (guideClickCount >= 4) {
            guideClickCount = 0
            showPinDialog = true
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("SOS Ring") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.primary
                )
            )
        },
        bottomBar = {
            NavigationBar {
                items.forEachIndexed { index, screen ->
                    NavigationBarItem(
                        icon = { Icon(screen.icon, contentDescription = screen.label) },
                        label = { Text(screen.label) },
                        selected = selectedItem == index,
                        onClick = {
                            selectedItem = index
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.startDestinationId)
                                launchSingleTop = true
                            }

                            if (screen == Screen.Help) {
                                onGuideSecretTap()
                            } else {
                                guideClickCount = 0
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Home.route) { HomeScreen(viewModel) }
            composable(Screen.Contacts.route) { ContactsScreen(viewModel) }
            composable(Screen.Settings.route) { SettingsScreen(viewModel) }
            composable(Screen.Help.route) { GuideScreen(onSecretTrigger = onGuideSecretTap) }
            composable(Screen.TestLab.route) {
                TestLabScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }

    // Dialog inserimento PIN segreto per accedere al Lab
    if (showPinDialog) {
        var enteredPin by remember { mutableStateOf("") }
        var isPinError by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = {
                showPinDialog = false
                enteredPin = ""
                isPinError = false
            },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Accesso Area Test Lab")
                }
            },
            text = {
                Column {
                    Text("Inserisci il PIN per sbloccare gli strumenti di stress test e debug:")
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = enteredPin,
                        onValueChange = {
                            enteredPin = it
                            isPinError = false
                        },
                        label = { Text("PIN di Sicurezza") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        isError = isPinError,
                        supportingText = if (isPinError) {
                            { Text("PIN non corretto. Riprova.", color = MaterialTheme.colorScheme.error) }
                        } else null,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (enteredPin == settings.labPin) {
                            showPinDialog = false
                            enteredPin = ""
                            isPinError = false
                            navController.navigate(Screen.TestLab.route)
                        } else {
                            isPinError = true
                        }
                    }
                ) {
                    Text("Sblocca")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showPinDialog = false
                        enteredPin = ""
                        isPinError = false
                    }
                ) {
                    Text("Annulla")
                }
            }
        )
    }
}
