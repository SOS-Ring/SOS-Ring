package com.example.ringbt_01

import android.bluetooth.BluetoothDevice
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ringbt_01.ble.BleManager
import com.example.ringbt_01.data.AppSettings
import com.example.ringbt_01.data.SettingsRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(
    private val repository: SettingsRepository,
    private val bleManager: BleManager
) : ViewModel() {

    val settings: StateFlow<AppSettings> = repository.settingsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = AppSettings()
    )

    val discoveredDevices: StateFlow<List<BluetoothDevice>> = bleManager.discoveredDevices
    val isBluetoothEnabled: StateFlow<Boolean> = bleManager.isBluetoothEnabled
    val connectionState: StateFlow<Int> = bleManager.connectionState

    fun startScanning() {
        bleManager.startScanning()
    }

    fun stopScanning() {
        bleManager.stopScanning()
    }

    fun isBtOn(): Boolean = bleManager.isBluetoothEnabled()

    fun updateContacts(c1: String, c2: String, c3: String) {
        viewModelScope.launch {
            repository.updateContacts(c1, c2, c3)
        }
    }

    fun updateSmsMessage(message: String) {
        viewModelScope.launch {
            repository.updateSmsMessage(message)
        }
    }

    fun updateSosRingAddress(address: String) {
        viewModelScope.launch {
            repository.updateSosRingAddress(address)
        }
    }

    fun updateAppTheme(theme: String) {
        viewModelScope.launch {
            repository.updateAppTheme(theme)
        }
    }

    fun disconnect() {
        viewModelScope.launch {
            repository.updateSosRingAddress("")
            bleManager.disconnect()
        }
    }

    // ── STRESS & TEST LAB (TEMPORANEO) ──────────────────────────────────────
    val debugLogs: StateFlow<List<String>> = com.example.ringbt_01.debug.DebugLogger.logs
    private val _countdown = kotlinx.coroutines.flow.MutableStateFlow(0)
    val countdown: StateFlow<Int> = _countdown

    fun simulateTriggerInstant() {
        com.example.ringbt_01.debug.DebugLogger.log("TEST", "👉 Iniezione manuale istantanea trigger 'ale23'")
        bleManager.simulateIncomingData("ale23")
    }

    fun startDelayedCountdownTrigger(seconds: Int = 10) {
        viewModelScope.launch {
            com.example.ringbt_01.debug.DebugLogger.log("TEST", "⏱️ Avvio countdown $seconds secondi per test a schermo spento...")
            for (i in seconds downTo 1) {
                _countdown.value = i
                kotlinx.coroutines.delay(1000)
            }
            _countdown.value = 0
            com.example.ringbt_01.debug.DebugLogger.log("TEST", "💥 Countdown terminato: invio 'ale23'!")
            bleManager.simulateIncomingData("ale23")
        }
    }

    fun cancelDelayedCountdown() {
        _countdown.value = 0
        com.example.ringbt_01.debug.DebugLogger.log("TEST", "❌ Countdown annullato")
    }

    fun simulateBurstStress(count: Int = 10, intervalMs: Long = 200L) {
        viewModelScope.launch {
            com.example.ringbt_01.debug.DebugLogger.log("TEST", "⚡ STRESS TEST: invio raffica di $count trigger 'ale23'...")
            for (i in 1..count) {
                com.example.ringbt_01.debug.DebugLogger.log("TEST", "Burst #$i/$count -> 'ale23'")
                bleManager.simulateIncomingData("ale23")
                kotlinx.coroutines.delay(intervalMs)
            }
            com.example.ringbt_01.debug.DebugLogger.log("TEST", "⚡ STRESS TEST completato. Verifica debounce ed esecuzione singola.")
        }
    }

    fun updateLabPin(pin: String) {
        viewModelScope.launch {
            repository.updateLabPin(pin)
        }
    }

    fun updateShowDebugToasts(enabled: Boolean) {
        viewModelScope.launch {
            repository.updateShowDebugToasts(enabled)
        }
    }

    fun clearDebugLogs() {
        com.example.ringbt_01.debug.DebugLogger.clear()
    }
}
