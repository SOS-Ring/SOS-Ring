package com.example.ringbt_01.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ringbt_01.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TestLabScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val settings by viewModel.settings.collectAsState()
    val debugLogs by viewModel.debugLogs.collectAsState()
    val countdown by viewModel.countdown.collectAsState()
    val listState = rememberLazyListState()

    var showChangePinDialog by remember { mutableStateOf(false) }

    // Auto-scroll all'ultimo log
    LaunchedEffect(debugLogs.size) {
        if (debugLogs.isNotEmpty()) {
            listState.animateScrollToItem(debugLogs.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Barra Superiore con pulsante Indietro
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Torna indietro")
            }
            Spacer(modifier = Modifier.width(4.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Laboratorio Stress Test",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Area Segreta di Collaudo & Debug",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Card 1: Configurazione Debug & Sicurezza PIN
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Opzioni Debug & Sicurezza",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium
                )
                
                Spacer(modifier = Modifier.height(8.dp))

                // Switch: Attiva/Disattiva Popup di Debug (Toast)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Popup di Debug a Schermo",
                            fontWeight = FontWeight.SemiBold,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = if (settings.showDebugToasts) "Attivi (mostra notifiche Toast temporanee)" else "Disattivi (modalità pulita definitiva)",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (settings.showDebugToasts) MaterialTheme.colorScheme.primary else Color.Gray
                        )
                    }
                    Switch(
                        checked = settings.showDebugToasts,
                        onCheckedChange = { isChecked ->
                            viewModel.updateShowDebugToasts(isChecked)
                            Toast.makeText(
                                context,
                                if (isChecked) "Popup di debug ATTIVATI" else "Popup di debug DISATTIVATI",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    )
                }

                Divider(modifier = Modifier.padding(vertical = 10.dp))

                // Pulsante: Cambia PIN di Accesso
                Button(
                    onClick = { showChangePinDialog = true },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                ) {
                    Icon(Icons.Default.LockReset, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Cambia PIN di Accesso (Attuale: ****)")
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Card 2: Azioni di Stress Test
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Simulazione Trigger ESP32 ('ale23')",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Pulsante 1: Trigger Subito
                Button(
                    onClick = {
                        viewModel.simulateTriggerInstant()
                        Toast.makeText(context, "Trigger 'ale23' simulato!", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.Default.FlashOn, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("1. Simula Trigger Subito")
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Pulsante 2: Countdown 10s per test a schermo spento
                if (countdown > 0) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "⏳ SPEGNI LO SCHERMO ADESSO!",
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.error,
                                fontSize = 15.sp
                            )
                            Text(
                                text = "Il trigger 'ale23' scatterà tra $countdown secondi...",
                                style = MaterialTheme.typography.bodySmall
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedButton(onClick = { viewModel.cancelDelayedCountdown() }) {
                                Text("Annulla Countdown")
                            }
                        }
                    }
                } else {
                    Button(
                        onClick = {
                            viewModel.startDelayedCountdownTrigger(10)
                            Toast.makeText(
                                context,
                                "Avviato! Hai 10 secondi per spegnere lo schermo e bloccare il telefono.",
                                Toast.LENGTH_LONG
                            ).show()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE65100))
                    ) {
                        Icon(Icons.Default.Timer, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("2. Test a Schermo Spento (Tra 10s)")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Pulsante 3: Burst Stress Test
                OutlinedButton(
                    onClick = {
                        viewModel.simulateBurstStress(count = 10, intervalMs = 200L)
                        Toast.makeText(
                            context,
                            "⚡ Inviati 10 pacchetti 'ale23' a raffica!",
                            Toast.LENGTH_SHORT
                        ).show()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Bolt, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("3. Burst Stress (10 trigger in 2s)")
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Console Log in Tempo Reale
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Console Eventi Live (${debugLogs.size})",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )
            TextButton(onClick = { viewModel.clearDebugLogs() }) {
                Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Pulisci")
            }
        }

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
            shape = RoundedCornerShape(8.dp)
        ) {
            if (debugLogs.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Nessun evento registrato. Esegui un test sopra!", color = Color.Gray, fontSize = 13.sp)
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(8.dp)
                ) {
                    items(debugLogs) { logLine ->
                        val logColor = when {
                            logLine.contains("[SOS]") -> Color(0xFFFF5252)
                            logLine.contains("[CALL]") -> Color(0xFF69F0AE)
                            logLine.contains("[SMS]") -> Color(0xFF40C4FF)
                            logLine.contains("[TEST]") -> Color(0xFFFFD740)
                            logLine.contains("❌") || logLine.contains("Errore") -> Color(0xFFFF5252)
                            else -> Color(0xFFE0E0E0)
                        }
                        Text(
                            text = logLine,
                            color = logColor,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            lineHeight = 14.sp
                        )
                    }
                }
            }
        }
    }

    // Dialog: Modifica PIN di Accesso
    if (showChangePinDialog) {
        var currentPinInput by remember { mutableStateOf("") }
        var newPinInput by remember { mutableStateOf("") }
        var confirmPinInput by remember { mutableStateOf("") }
        var errorMessage by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showChangePinDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Cambia PIN Lab")
                }
            },
            text = {
                Column {
                    Text("Imposta un nuovo PIN per sbloccare l'accesso al Lab:", style = MaterialTheme.typography.bodyMedium)
                    
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = currentPinInput,
                        onValueChange = { currentPinInput = it; errorMessage = null },
                        label = { Text("PIN Attuale") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = newPinInput,
                        onValueChange = { newPinInput = it; errorMessage = null },
                        label = { Text("Nuovo PIN") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = confirmPinInput,
                        onValueChange = { confirmPinInput = it; errorMessage = null },
                        label = { Text("Conferma Nuovo PIN") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (errorMessage != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = errorMessage ?: "",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (currentPinInput != settings.labPin) {
                            errorMessage = "Il PIN attuale non è corretto."
                        } else if (newPinInput.isBlank() || newPinInput.length < 4) {
                            errorMessage = "Il nuovo PIN deve contenere almeno 4 caratteri."
                        } else if (newPinInput != confirmPinInput) {
                            errorMessage = "I due nuovi PIN non coincidono."
                        } else {
                            viewModel.updateLabPin(newPinInput)
                            Toast.makeText(context, "PIN aggiornato con successo!", Toast.LENGTH_SHORT).show()
                            showChangePinDialog = false
                        }
                    }
                ) {
                    Text("Salva PIN")
                }
            },
            dismissButton = {
                TextButton(onClick = { showChangePinDialog = false }) {
                    Text("Annulla")
                }
            }
        )
    }
}
