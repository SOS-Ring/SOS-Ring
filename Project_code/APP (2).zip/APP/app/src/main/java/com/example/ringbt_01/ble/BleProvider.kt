package com.example.ringbt_01.ble

import android.content.Context

object BleProvider {
    @Volatile
    private var instance: BleManager? = null

    fun getBleManager(context: Context): BleManager {
        return instance ?: synchronized(this) {
            instance ?: BleManager(context.applicationContext).also { instance = it }
        }
    }
}
