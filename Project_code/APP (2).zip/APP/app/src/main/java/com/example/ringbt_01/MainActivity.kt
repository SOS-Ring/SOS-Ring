package com.example.ringbt_01

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ringbt_01.data.SettingsRepository
import com.example.ringbt_01.service.BLEForegroundService
import com.example.ringbt_01.ui.screens.MainScreen
import com.example.ringbt_01.ui.theme.RingBT_01Theme
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                android.view.WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
                android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }
        
        val repository = SettingsRepository(applicationContext)
        val bleManager = com.example.ringbt_01.ble.BleProvider.getBleManager(applicationContext)
        val viewModelFactory = object : ViewModelProvider.Factory {
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return MainViewModel(repository, bleManager) as T
            }
        }

        setContent {
            val viewModel: MainViewModel = viewModel(factory = viewModelFactory)
            val settings by viewModel.settings.collectAsState()

            RingBT_01Theme(selectedTheme = settings.appTheme) {
                var initialPermissionFlowFinished by remember { mutableStateOf(false) }

                val permissionsToRequest = mutableListOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.SEND_SMS,
                    Manifest.permission.CALL_PHONE,
                    Manifest.permission.READ_CONTACTS,
                    Manifest.permission.READ_PHONE_STATE
                ).apply {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        add(Manifest.permission.ANSWER_PHONE_CALLS)
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        add(Manifest.permission.BLUETOOTH_SCAN)
                        add(Manifest.permission.BLUETOOTH_CONNECT)
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        add(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }

                val backgroundLocationLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.RequestPermission()
                ) { isGranted ->
                    Log.d("MainActivity", "Background location permission granted: $isGranted")
                    startServiceIfPermitted()
                    initialPermissionFlowFinished = true
                }

                val launcher = rememberLauncherForActivityResult(
                    ActivityResultContracts.RequestMultiplePermissions()
                ) { permissions ->
                    Log.d("MainActivity", "Permissions result: $permissions")
                    
                    val fineLocationGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true
                    val coarseLocationGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
                    val hasForegroundLocation = fineLocationGranted || coarseLocationGranted

                    // Dopo i permessi base, richiedi ACCESS_BACKGROUND_LOCATION solo se la location foreground è stata concessa
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && hasForegroundLocation) {
                        try {
                            backgroundLocationLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                        } catch (e: Exception) {
                            Log.e("MainActivity", "Errore richiesta background location", e)
                            startServiceIfPermitted()
                            initialPermissionFlowFinished = true
                        }
                    } else {
                        startServiceIfPermitted()
                        initialPermissionFlowFinished = true
                    }
                }

                // ROLE_DIALER rimosso: l'app NON deve essere il dialer predefinito.
                // Le chiamate vengono gestite dall'app telefono di sistema.

                LaunchedEffect(Unit) {
                    launcher.launch(permissionsToRequest.toTypedArray())
                }

                LaunchedEffect(initialPermissionFlowFinished) {
                    if (initialPermissionFlowFinished) {
                        // Chiedi di disattivare ottimizzazione batteria se necessario (in modo sicuro)
                        requestBatteryOptimization(this@MainActivity)
                    }
                }

                MainScreen(viewModel)
            }
        }
    }

    private fun requestBatteryOptimization(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
                if (pm != null && !pm.isIgnoringBatteryOptimizations(context.packageName)) {
                    val intent = Intent().apply {
                        action = Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS
                        data = Uri.parse("package:${context.packageName}")
                    }
                    context.startActivity(intent)
                }
            } catch (e: Exception) {
                Log.w("MainActivity", "Impossibile aprire richiesta ignorare ottimizzazione batteria", e)
            }
        }
    }

    private fun startServiceIfPermitted() {
        val hasBt = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            androidx.core.content.ContextCompat.checkSelfPermission(
                this, Manifest.permission.BLUETOOTH_CONNECT
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        } else true

        val hasLocation = androidx.core.content.ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED ||
        androidx.core.content.ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_COARSE_LOCATION
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED

        if (hasBt && hasLocation) {
            try {
                val intent = Intent(this, BLEForegroundService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(intent)
                } else {
                    startService(intent)
                }
            } catch (e: Exception) {
                Log.e("MainActivity", "Errore avvio BLEForegroundService", e)
            }
        } else {
            Log.w("MainActivity", "BLEForegroundService non avviato: permessi mancanti (BT=$hasBt, Loc=$hasLocation)")
        }
    }
}
