package com.example.ringbt_01.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = Purple80,
    secondary = PurpleGrey80,
    tertiary = Pink80
)

private val LightColorScheme = lightColorScheme(
    primary = Purple40,
    secondary = PurpleGrey40,
    tertiary = Pink40
)

// Custom Color Schemes
val DarkRedColorScheme = darkColorScheme(
    primary = DarkRedPrimary,
    onPrimary = DarkRedOnPrimary,
    primaryContainer = DarkRedPrimaryContainer,
    onPrimaryContainer = DarkRedOnPrimaryContainer,
    background = DarkRedBackground,
    onBackground = Color.White,
    surface = DarkRedSurface,
    onSurface = Color.White,
    surfaceVariant = DarkRedSurfaceVariant,
    onSurfaceVariant = Color(0xFFE0E0E0),
    error = Color(0xFFFF5252)
)

val DarkYellowColorScheme = darkColorScheme(
    primary = DarkYellowPrimary,
    onPrimary = DarkYellowOnPrimary,
    primaryContainer = DarkYellowPrimaryContainer,
    onPrimaryContainer = DarkYellowOnPrimaryContainer,
    background = DarkYellowBackground,
    onBackground = Color.White,
    surface = DarkYellowSurface,
    onSurface = Color.White,
    surfaceVariant = DarkYellowSurfaceVariant,
    onSurfaceVariant = Color(0xFFE0E0E0),
    error = Color(0xFFFF5252)
)

val DarkGreenColorScheme = darkColorScheme(
    primary = DarkGreenPrimary,
    onPrimary = DarkGreenOnPrimary,
    primaryContainer = DarkGreenPrimaryContainer,
    onPrimaryContainer = DarkGreenOnPrimaryContainer,
    background = DarkGreenBackground,
    onBackground = Color.White,
    surface = DarkGreenSurface,
    onSurface = Color.White,
    surfaceVariant = DarkGreenSurfaceVariant,
    onSurfaceVariant = Color(0xFFE0E0E0),
    error = Color(0xFFFF5252)
)

val DarkBlueColorScheme = darkColorScheme(
    primary = DarkBluePrimary,
    onPrimary = DarkBlueOnPrimary,
    primaryContainer = DarkBluePrimaryContainer,
    onPrimaryContainer = DarkBlueOnPrimaryContainer,
    background = DarkBlueBackground,
    onBackground = Color.White,
    surface = DarkBlueSurface,
    onSurface = Color.White,
    surfaceVariant = DarkBlueSurfaceVariant,
    onSurfaceVariant = Color(0xFFE0E0E0),
    error = Color(0xFFFF5252)
)

val LightWhiteColorScheme = lightColorScheme(
    primary = LightWhitePrimary,
    onPrimary = LightWhiteOnPrimary,
    primaryContainer = LightWhitePrimaryContainer,
    onPrimaryContainer = LightWhiteOnPrimaryContainer,
    background = LightWhiteBackground,
    onBackground = LightWhiteOnSurface,
    surface = LightWhiteSurface,
    onSurface = LightWhiteOnSurface,
    surfaceVariant = LightWhiteSurfaceVariant,
    onSurfaceVariant = LightWhiteOnSurfaceVariant
)

@Composable
fun RingBT_01Theme(
    selectedTheme: String = "SYSTEM",
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val colorScheme = when (selectedTheme) {
        "DARK_RED" -> DarkRedColorScheme
        "DARK_YELLOW" -> DarkYellowColorScheme
        "DARK_GREEN" -> DarkGreenColorScheme
        "DARK_BLUE" -> DarkBlueColorScheme
        "LIGHT_WHITE" -> LightWhiteColorScheme
        else -> {
            // SYSTEM
            when {
                dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
                    if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
                }
                darkTheme -> DarkColorScheme
                else -> LightColorScheme
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}